import React, { useEffect, useState } from 'react';
import { collection, getDocs, deleteDoc, doc } from 'firebase/firestore';
import { db } from '../../../firebase'; // Adjust the import path if necessary

function Users() {
  const [users, setUsers] = useState([]);
  const [error, setError] = useState('');

  // Fetch user data from Firestore
  useEffect(() => {
    const fetchUsers = async () => {
      const usersCollection = collection(db, 'users');
      try {
        const querySnapshot = await getDocs(usersCollection);
        const userData = [];

        querySnapshot.forEach((doc) => {
          userData.push({ id: doc.id, ...doc.data() });
        });

        setUsers(userData); // Set the fetched users data to state
      } catch (error) {
        setError('Error fetching user data');
        console.error('Error fetching users:', error);
      }
    };

    fetchUsers();
  }, []);

  // Handle delete user
  const handleDelete = async (userId) => {
    const userDoc = doc(db, 'users', userId);
    try {
      await deleteDoc(userDoc);
      // Update state to remove deleted user
      setUsers(users.filter(user => user.id !== userId));
    } catch (error) {
      console.error('Error deleting user:', error);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-900 p-6">
      <h1 className="text-3xl text-white mb-6">Users</h1>
      {error && <p className="text-red-500">{error}</p>}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {users.map(user => (
          <div key={user.id} className="bg-white p-4 rounded shadow-md flex justify-between items-center">
            <div>
              <h2 className="text-lg font-semibold">{user.FullName || user.NGO_name || user.Organization_name}</h2>
              <p className="text-sm text-gray-600">Role: {user.Role}</p>
            </div>
            <button 
              onClick={() => handleDelete(user.id)} 
              className="bg-red-500 text-white px-3 py-1 rounded"
            >
              Delete
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Users;
