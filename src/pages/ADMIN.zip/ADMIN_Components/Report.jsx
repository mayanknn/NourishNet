import React, { useEffect } from 'react';
import AdminGraphs from './AdminGraph';


function Report() {
  
  return (
    <div>
      Report
      <AdminGraphs />
    </div>
  );
}

export default Report;
